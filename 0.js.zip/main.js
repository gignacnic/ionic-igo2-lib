(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0owmtgfs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0owmtgfs.entry.js",
		"common",
		58
	],
	"./0owmtgfs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0owmtgfs.sc.entry.js",
		"common",
		59
	],
	"./0utrggve.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0utrggve.entry.js",
		"common",
		60
	],
	"./0utrggve.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0utrggve.sc.entry.js",
		"common",
		61
	],
	"./1bo3p9bf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1bo3p9bf.entry.js",
		"common",
		10
	],
	"./1bo3p9bf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1bo3p9bf.sc.entry.js",
		"common",
		11
	],
	"./1z2sd9l6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1z2sd9l6.entry.js",
		"common",
		12
	],
	"./1z2sd9l6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1z2sd9l6.sc.entry.js",
		"common",
		13
	],
	"./3hf0d5sl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hf0d5sl.entry.js",
		"common",
		62
	],
	"./3hf0d5sl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hf0d5sl.sc.entry.js",
		"common",
		63
	],
	"./47ctf96j.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/47ctf96j.entry.js",
		0,
		"common",
		132
	],
	"./47ctf96j.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/47ctf96j.sc.entry.js",
		0,
		"common",
		133
	],
	"./4jebvdzz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4jebvdzz.entry.js",
		"common",
		14
	],
	"./4jebvdzz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4jebvdzz.sc.entry.js",
		"common",
		15
	],
	"./4m739wpj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4m739wpj.entry.js",
		"common",
		64
	],
	"./4m739wpj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4m739wpj.sc.entry.js",
		"common",
		65
	],
	"./4ovfvgj2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4ovfvgj2.entry.js",
		0,
		"common",
		134
	],
	"./4ovfvgj2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4ovfvgj2.sc.entry.js",
		0,
		"common",
		135
	],
	"./5ccusvgf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ccusvgf.entry.js",
		"common",
		66
	],
	"./5ccusvgf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ccusvgf.sc.entry.js",
		"common",
		67
	],
	"./6f4biktp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6f4biktp.entry.js",
		"common",
		68
	],
	"./6f4biktp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6f4biktp.sc.entry.js",
		"common",
		69
	],
	"./8ldpeqpe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8ldpeqpe.entry.js",
		"common",
		16
	],
	"./8ldpeqpe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8ldpeqpe.sc.entry.js",
		"common",
		17
	],
	"./8q1e6dus.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8q1e6dus.entry.js",
		"common",
		18
	],
	"./8q1e6dus.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8q1e6dus.sc.entry.js",
		"common",
		19
	],
	"./9rhd7ueu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9rhd7ueu.entry.js",
		0,
		"common",
		136
	],
	"./9rhd7ueu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9rhd7ueu.sc.entry.js",
		0,
		"common",
		137
	],
	"./9ynbzp83.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9ynbzp83.entry.js",
		"common",
		20
	],
	"./9ynbzp83.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9ynbzp83.sc.entry.js",
		"common",
		21
	],
	"./a4llz05d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/a4llz05d.entry.js",
		"common",
		70
	],
	"./a4llz05d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/a4llz05d.sc.entry.js",
		"common",
		71
	],
	"./afjpklm4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/afjpklm4.entry.js",
		"common",
		72
	],
	"./afjpklm4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/afjpklm4.sc.entry.js",
		"common",
		73
	],
	"./b2tc2xce.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b2tc2xce.entry.js",
		0,
		"common",
		138
	],
	"./b2tc2xce.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b2tc2xce.sc.entry.js",
		0,
		"common",
		139
	],
	"./c2kiol1t.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2kiol1t.entry.js",
		"common",
		22
	],
	"./c2kiol1t.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2kiol1t.sc.entry.js",
		"common",
		23
	],
	"./ch8upsxn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ch8upsxn.entry.js",
		0,
		"common",
		114
	],
	"./ch8upsxn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ch8upsxn.sc.entry.js",
		0,
		"common",
		115
	],
	"./coytbtgb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coytbtgb.entry.js",
		"common",
		78
	],
	"./coytbtgb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coytbtgb.sc.entry.js",
		"common",
		79
	],
	"./cuwemyof.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cuwemyof.entry.js",
		"common",
		80
	],
	"./cuwemyof.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cuwemyof.sc.entry.js",
		"common",
		81
	],
	"./cyhnsxpk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cyhnsxpk.entry.js",
		0,
		"common",
		142
	],
	"./cyhnsxpk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cyhnsxpk.sc.entry.js",
		0,
		"common",
		143
	],
	"./e9ulkkay.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/e9ulkkay.entry.js",
		144
	],
	"./e9ulkkay.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/e9ulkkay.sc.entry.js",
		145
	],
	"./fcbdrndu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fcbdrndu.entry.js",
		"common",
		82
	],
	"./fcbdrndu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fcbdrndu.sc.entry.js",
		"common",
		83
	],
	"./ffukzwt6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.entry.js",
		"common",
		122
	],
	"./ffukzwt6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.sc.entry.js",
		"common",
		123
	],
	"./fhznfhbd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fhznfhbd.entry.js",
		"common",
		24
	],
	"./fhznfhbd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fhznfhbd.sc.entry.js",
		"common",
		25
	],
	"./fiqi6app.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.entry.js",
		146
	],
	"./fiqi6app.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.sc.entry.js",
		147
	],
	"./g0yheybk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g0yheybk.entry.js",
		0,
		"common",
		148
	],
	"./g0yheybk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g0yheybk.sc.entry.js",
		0,
		"common",
		149
	],
	"./gvyg1bwh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gvyg1bwh.entry.js",
		"common",
		26
	],
	"./gvyg1bwh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gvyg1bwh.sc.entry.js",
		"common",
		27
	],
	"./i9lnulrx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i9lnulrx.entry.js",
		"common",
		28
	],
	"./i9lnulrx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i9lnulrx.sc.entry.js",
		"common",
		29
	],
	"./iz1p89vi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iz1p89vi.entry.js",
		2,
		"common",
		150
	],
	"./iz1p89vi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iz1p89vi.sc.entry.js",
		2,
		"common",
		151
	],
	"./jdcptvrs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdcptvrs.entry.js",
		"common",
		84
	],
	"./jdcptvrs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdcptvrs.sc.entry.js",
		"common",
		85
	],
	"./jpkvsu5y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.entry.js",
		"common",
		124
	],
	"./jpkvsu5y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.sc.entry.js",
		"common",
		125
	],
	"./jtkjzkgg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtkjzkgg.entry.js",
		"common",
		30
	],
	"./jtkjzkgg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtkjzkgg.sc.entry.js",
		"common",
		31
	],
	"./jwqvpjte.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jwqvpjte.entry.js",
		"common",
		86
	],
	"./jwqvpjte.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jwqvpjte.sc.entry.js",
		"common",
		87
	],
	"./jyrjuxdj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyrjuxdj.entry.js",
		"common",
		32
	],
	"./jyrjuxdj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyrjuxdj.sc.entry.js",
		"common",
		33
	],
	"./kw6qlege.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kw6qlege.entry.js",
		"common",
		74
	],
	"./kw6qlege.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kw6qlege.sc.entry.js",
		"common",
		75
	],
	"./l22q7ddp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/l22q7ddp.entry.js",
		"common",
		126
	],
	"./l22q7ddp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/l22q7ddp.sc.entry.js",
		"common",
		127
	],
	"./lqvrsauo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqvrsauo.entry.js",
		"common",
		88
	],
	"./lqvrsauo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqvrsauo.sc.entry.js",
		"common",
		89
	],
	"./ly8zbpmk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ly8zbpmk.entry.js",
		"common",
		34
	],
	"./ly8zbpmk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ly8zbpmk.sc.entry.js",
		"common",
		35
	],
	"./mny78lhg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mny78lhg.entry.js",
		0,
		"common",
		152
	],
	"./mny78lhg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mny78lhg.sc.entry.js",
		0,
		"common",
		153
	],
	"./n361sgpa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n361sgpa.entry.js",
		"common",
		36
	],
	"./n361sgpa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n361sgpa.sc.entry.js",
		"common",
		37
	],
	"./nr6wcehx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nr6wcehx.entry.js",
		"common",
		38
	],
	"./nr6wcehx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nr6wcehx.sc.entry.js",
		"common",
		39
	],
	"./ntxo2f3d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ntxo2f3d.entry.js",
		"common",
		40
	],
	"./ntxo2f3d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ntxo2f3d.sc.entry.js",
		"common",
		41
	],
	"./nxacca4l.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxacca4l.entry.js",
		0,
		"common",
		154
	],
	"./nxacca4l.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxacca4l.sc.entry.js",
		0,
		"common",
		155
	],
	"./nxghvzhm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxghvzhm.entry.js",
		"common",
		42
	],
	"./nxghvzhm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxghvzhm.sc.entry.js",
		"common",
		43
	],
	"./oboc8zd4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oboc8zd4.entry.js",
		"common",
		90
	],
	"./oboc8zd4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oboc8zd4.sc.entry.js",
		"common",
		91
	],
	"./odqmlmdd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/odqmlmdd.entry.js",
		"common",
		44
	],
	"./odqmlmdd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/odqmlmdd.sc.entry.js",
		"common",
		45
	],
	"./psxwmesv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/psxwmesv.entry.js",
		0,
		"common",
		156
	],
	"./psxwmesv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/psxwmesv.sc.entry.js",
		0,
		"common",
		157
	],
	"./qtcvseqn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qtcvseqn.entry.js",
		0,
		"common",
		158
	],
	"./qtcvseqn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qtcvseqn.sc.entry.js",
		0,
		"common",
		159
	],
	"./qvwswew4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.entry.js",
		"common",
		116
	],
	"./qvwswew4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.sc.entry.js",
		"common",
		117
	],
	"./raunowwy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/raunowwy.entry.js",
		"common",
		92
	],
	"./raunowwy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/raunowwy.sc.entry.js",
		"common",
		93
	],
	"./s347396r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s347396r.entry.js",
		"common",
		46
	],
	"./s347396r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s347396r.sc.entry.js",
		"common",
		47
	],
	"./sdfyvdro.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sdfyvdro.entry.js",
		"common",
		94
	],
	"./sdfyvdro.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sdfyvdro.sc.entry.js",
		"common",
		95
	],
	"./sghmhl28.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sghmhl28.entry.js",
		"common",
		48
	],
	"./sghmhl28.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sghmhl28.sc.entry.js",
		"common",
		49
	],
	"./sjcqnbtt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sjcqnbtt.entry.js",
		"common",
		96
	],
	"./sjcqnbtt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sjcqnbtt.sc.entry.js",
		"common",
		97
	],
	"./t547wlk7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.entry.js",
		"common",
		118
	],
	"./t547wlk7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.sc.entry.js",
		"common",
		119
	],
	"./ta1bgxgm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ta1bgxgm.entry.js",
		"common",
		98
	],
	"./ta1bgxgm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ta1bgxgm.sc.entry.js",
		"common",
		99
	],
	"./tui62q7d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tui62q7d.entry.js",
		"common",
		100
	],
	"./tui62q7d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tui62q7d.sc.entry.js",
		"common",
		101
	],
	"./tylmm2yl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tylmm2yl.entry.js",
		"common",
		102
	],
	"./tylmm2yl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tylmm2yl.sc.entry.js",
		"common",
		103
	],
	"./uegz8gm3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uegz8gm3.entry.js",
		"common",
		104
	],
	"./uegz8gm3.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uegz8gm3.sc.entry.js",
		"common",
		105
	],
	"./uyartgdr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uyartgdr.entry.js",
		0,
		"common",
		160
	],
	"./uyartgdr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uyartgdr.sc.entry.js",
		0,
		"common",
		161
	],
	"./vbuvdxh8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vbuvdxh8.entry.js",
		2,
		"common",
		162
	],
	"./vbuvdxh8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vbuvdxh8.sc.entry.js",
		2,
		"common",
		163
	],
	"./vjeei8vr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vjeei8vr.entry.js",
		"common",
		76
	],
	"./vjeei8vr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vjeei8vr.sc.entry.js",
		"common",
		77
	],
	"./wy4rjeqs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wy4rjeqs.entry.js",
		0,
		"common",
		120
	],
	"./wy4rjeqs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wy4rjeqs.sc.entry.js",
		0,
		"common",
		121
	],
	"./xbafxwto.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xbafxwto.entry.js",
		0,
		"common",
		164
	],
	"./xbafxwto.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xbafxwto.sc.entry.js",
		0,
		"common",
		165
	],
	"./xfbndl84.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xfbndl84.entry.js",
		"common",
		50
	],
	"./xfbndl84.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xfbndl84.sc.entry.js",
		"common",
		51
	],
	"./xgnma4yj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xgnma4yj.entry.js",
		"common",
		106
	],
	"./xgnma4yj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xgnma4yj.sc.entry.js",
		"common",
		107
	],
	"./xrxaow8a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrxaow8a.entry.js",
		"common",
		108
	],
	"./xrxaow8a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrxaow8a.sc.entry.js",
		"common",
		109
	],
	"./ycyyhg01.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ycyyhg01.entry.js",
		"common",
		110
	],
	"./ycyyhg01.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ycyyhg01.sc.entry.js",
		"common",
		111
	],
	"./ygh0szo0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ygh0szo0.entry.js",
		"common",
		52
	],
	"./ygh0szo0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ygh0szo0.sc.entry.js",
		"common",
		53
	],
	"./yl6smbo0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yl6smbo0.entry.js",
		"common",
		128
	],
	"./yl6smbo0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yl6smbo0.sc.entry.js",
		"common",
		129
	],
	"./z9eemkqi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9eemkqi.entry.js",
		"common",
		54
	],
	"./z9eemkqi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9eemkqi.sc.entry.js",
		"common",
		55
	],
	"./z9nt6ntd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.entry.js",
		"common",
		130
	],
	"./z9nt6ntd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.sc.entry.js",
		"common",
		131
	],
	"./zktscnoo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zktscnoo.entry.js",
		"common",
		112
	],
	"./zktscnoo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zktscnoo.sc.entry.js",
		"common",
		113
	],
	"./zykaqnfi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zykaqnfi.entry.js",
		"common",
		56
	],
	"./zykaqnfi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zykaqnfi.sc.entry.js",
		"common",
		57
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', loadChildren: './home/home.module#HomePageModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, renderer) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.renderer = renderer;
        this.themeClass = 'indigo-theme';
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
            _this.renderer.addClass(document.body, _this.themeClass);
        });
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]],
            entryComponents: [],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_8__["BrowserAnimationsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"]
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Mrnmicro\dev\Igo2Test\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map